import numpy as np
import pandas as pd
from dataview import mainclass
from flask import Flask, request, render_template, redirect
app = Flask(__name__)

#Need to do this always, just change the homepage value to the page value
# @app.route('/')
# def index():
#     return 'HomePage <h1> awesome </h1>'
# compulsory stuff

#Just for checking out the methods
# @app.route('/dummy', methods=['GET', 'POST'])
# def dummy():
#     return 'Medhod used %s' % request.method

@app.route('/', methods=['GET','POST'])
def index():
    classinstance = mainclass()
    input_num = request.form['text']
    input_num_i = int(input_num)
    print(request.form)
    dataset_tab = classinstance.seedata(5)
    return render_template('view.html', tables=[dataset_tab])

@app.route('/relevancy/<name>')
def relevancy(name):
    return render_template('relevancy.html', name=name)

if __name__ == "__main__":
    app.run(debug=True)