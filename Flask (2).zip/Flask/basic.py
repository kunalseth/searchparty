import numpy as np
import pandas as pd
from dataview import mainclass
from flask import Flask, request, render_template
app = Flask(__name__)

#Need to do this always, just change the homepage value to the page value
@app.route('/')
def index():
    return 'HomePage <h1> awesome </h1>'
# compulsory stuff

#Just for checking out the methods
# @app.route('/dummy', methods=['GET', 'POST'])
# def dummy():
#     return 'Medhod used %s' % request.method


@app.route('/tables', methods=['GET','POST'])
def tables():
    classinstance = mainclass()
    # return classinstance.seedata()
    # dataset = pd.read_csv('data.csv')
    # dataset_tab = dataset.head(10)
    # return render_template('view.html', tables=[dataset_tab.to_html()])
    input_num = request.form['inputnumber']
    input_num_i = int(input_num)
    dataset_tab = classinstance.seedata(input_num_i)
    return render_template('view.html', tables=[dataset_tab])

@app.route('/relevancy/<name>')
def relevancy(name):
    return render_template('relevancy.html', name=name)

if __name__ == "__main__":
    app.run(debug=True)